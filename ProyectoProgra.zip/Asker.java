/******************************************************************
almacen.java
Autores: Stefano Aragoni, Rebecca Smith, Roberto Vallecillos, Cayetano molina, Daniel Cabrera, Diego Ruiz
Última modificación: 2020-11-02

******************************************************************/
import java.util.Scanner;

class Asker{

  Scanner scan = new Scanner(System.in);

  

  //scanner para numeros
  public int nextInt(){
    int opcion = 0;
    while(opcion == 0){
      try{
        opcion = scan.nextInt();
      }catch(Exception e){
        System.out.println("Por favor ingresa un numero correcto."); 
        scan.next();
        continue;
      }
      
    }
    return opcion;
  }

  //scanner de strings
  public String next(){
    String opcion = scan.next();
    return opcion;
  }

}
public interface Actividad{
  public void MenuNivel(int a);

  public int Nivel1(int opcion);
  public int Nivel2(int opcion);
  public int Nivel3(int opcion);
  public int Nivel4(int opcion);
  public int Nivel5(int opcion);
}